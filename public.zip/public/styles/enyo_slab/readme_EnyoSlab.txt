ENYO SLAB
Typeface � ANTIPIXEL. 2014. All Rights Reserved
www.antipixel.com.ar
Julia Martinez Diana.

This font is free for personal use only.
For commercial use, please contact me to info@antipixel.com.ar with any questions beforehand, or purchase the license you require at MyFonts: http://www.myfonts.com/fonts/antipixel/enyo/

Este tipograf�a es gratis s�lo para uso personal.
En caso de requerirla para uso comercial, por favor contactame por cualquier duda a info@antipixel.com, o adquir� la licencia en MyFonts: http://www.myfonts.com/fonts/antipixel/enyo/


Thanks!
Gracias!